export class PaintingImage {
    constructor(
        public width: number,
        public height: number,
        public url: string
    ) {}
}

export class Painting
{
    constructor(
        public objectNumber: string,
        public title: string,
        public permitDownload: boolean,
        public image: PaintingImage, 
        public isFavorite: boolean
    ) {}
}
