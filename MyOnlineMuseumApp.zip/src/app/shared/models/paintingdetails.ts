export class PaintingDetailImage {
    constructor(
        public width: number,
        public height: number,
        public url: string
    ) {}
}

export class PaintingDetails
{
    constructor(
        public objectNumber: string,
        public title: string,
        public description: string,
        public image: PaintingDetailImage
    ) {}
}
