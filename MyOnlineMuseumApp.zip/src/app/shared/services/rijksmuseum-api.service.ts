import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/observable/of';

import { RootObject, ArtObjects, ArtObject } from '../interfaces/rijksmuseum-api.interfaces'; 
import { Painting, PaintingImage } from '../models/paintings';
import { PaintingDetails, PaintingDetailImage } from '../models/paintingdetails';

const WebUrl = 'https://www.rijksmuseum.nl/api/nl/collection';

@Injectable()
export class RijksmuseumApiService {

  constructor(private http : HttpClient) 
  { }

  private KeyUrl = '?key=ZXwaBYE1&format=json';

  getCollectionByName(name: string): Observable<Painting[]> 
  {
    var url = encodeURI(`${WebUrl}${this.KeyUrl}&q=${name}`);
    
    return this.http.get<RootObject>(url)
			.map(response => {
        return response.artObjects.map((artObjects: ArtObjects) => { 
          let paintingImage = null;
          if (artObjects.webImage != null && artObjects.webImage.url != null)
            paintingImage = new PaintingImage(artObjects.webImage.width, artObjects.webImage.height, artObjects.webImage.url);
          return new Painting(artObjects.objectNumber, artObjects.title, artObjects.permitDownload, paintingImage, false);
        })
      })
			.catch(this.handleError);
  }
  
  getDetailInfoFromPainting(objectNumber: string): Observable<PaintingDetails> 
  {
    var url = encodeURI(`${WebUrl}/${objectNumber}${this.KeyUrl}`);

    return this.http.get<RootObject>(url)
			.map(response => {
        const artObject: ArtObject = response.artObject;
        let paintingImage = null;
        if (artObject.webImage != null && artObject.webImage.url != null)
          paintingImage = new PaintingDetailImage(artObject.webImage.width, artObject.webImage.height, artObject.webImage.url);
        else
          paintingImage = new PaintingDetailImage(100, 100, "./assets/images/NoImageAvailable.jpg");
        return new PaintingDetails(artObject.objectNumber, artObject.title, artObject.description, paintingImage);
      })
      .catch(this.handleError);
  }

  private handleError(error: Response | any) {
    console.log('rijksmuseum-api-service::error', error);
    return Observable.of(null);
  }
 
}
