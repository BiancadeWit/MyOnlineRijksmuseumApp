import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { RijksmuseumApiService } from '../shared/services/rijksmuseum-api.service';
import { PaintingDetails } from '../shared/models/paintingdetails';

import { Observable } from 'rxjs/Observable';
import { Subscriber } from 'rxjs/Subscriber';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-painting-details',
  templateUrl: './painting-details.component.html',
  styleUrls: ['./painting-details.component.css']
})

export class PaintingDetailsComponent implements OnChanges 
{
  @Input() objectNumber: string;
  @Input() isFavorite: boolean;
  @Output() changedFavorite: EventEmitter<boolean> = new EventEmitter<boolean>();

  paintingDetails$: Observable<PaintingDetails>;
  
  /*sub: Subscription;
  name: string;*/

  constructor(private apiService: RijksmuseumApiService, private router: Router, private route: ActivatedRoute) 
  { }

  ngOnChanges() 
  {
    this.paintingDetails$ = this.apiService.getDetailInfoFromPainting(this.objectNumber);

      //this.sub = this.route.params.subscribe((params: any) => { this.name = params['name']; });
  }

  ngOnDestroy()
  {
    //this.sub.unsubscribe();
  }

  changeFavorite()
  {
    this.isFavorite = !this.isFavorite;
		this.changedFavorite.emit(this.isFavorite);
  }

  /*goBack()
  {
    this.router.navigate(['home']);
  }*/
}
