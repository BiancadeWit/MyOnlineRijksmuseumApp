import { Component, OnInit, Input } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { RijksmuseumApiService } from '../shared/services/rijksmuseum-api.service';
import { Painting, PaintingImage } from '../shared/models/paintings';

@Component({
  selector: 'app-collection-search',
  templateUrl: './collection-search.component.html',
  styleUrls: ['./collection-search.component.css']
})

export class CollectionSearchComponent {

  paintings$: Observable<Painting[]>;

  constructor(private apiService: RijksmuseumApiService) {}
 
  searchPaintingsByName(name : string) : void 
  {
    this.paintings$ = this.apiService.getCollectionByName(name);
  }
}
