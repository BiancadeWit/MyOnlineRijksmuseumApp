// app.routes.ts
import { Routes } from '@angular/router';
import { AppComponent } from "./app.component";
import { CollectionSearchComponent } from './collection-search/collection-search.component';
import { PaintingDetailsComponent } from './painting-details/painting-details.component';

export const AppRoutes: Routes = [
	{path: '', component: CollectionSearchComponent},
    {path: 'home', component: CollectionSearchComponent},
    {path: 'detail/:name', component: PaintingDetailsComponent},
    {
        // catch all route
        path     : '**',
        redirectTo: 'home'
    },
];
