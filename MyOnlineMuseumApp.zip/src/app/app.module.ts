import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

// Router
import { RouterModule } from '@angular/router';
import { AppRoutes } from './app.routes';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { RijksmuseumApiService } from './shared/services/rijksmuseum-api.service';
import { CollectionListComponent } from './collection-list/collection-list.component';
import { PaintingDetailsComponent } from './painting-details/painting-details.component';
import { CollectionSearchComponent } from './collection-search/collection-search.component';

@NgModule({
  declarations: [
    AppComponent,
    CollectionListComponent,
    PaintingDetailsComponent,
    CollectionSearchComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    NgbModule.forRoot(),
    RouterModule.forRoot(AppRoutes)
  ],
  providers: [RijksmuseumApiService],
  bootstrap: [AppComponent]
})

export class AppModule { }
