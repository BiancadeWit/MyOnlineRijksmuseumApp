import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Observable } from 'rxjs/Observable';

import { Painting, PaintingImage } from '../shared/models/paintings'
import { PaintingDetails } from '../shared/models/paintingdetails';

@Component({
  selector: 'app-collection-list',
  templateUrl: './collection-list.component.html',
  styleUrls: ['./collection-list.component.css']
})

export class CollectionListComponent implements OnChanges
{

  @Input() paintings$: Observable<Painting[]>;
  choosenPainting: Painting;

  constructor() { }

  ngOnChanges(changes: SimpleChanges)
  {
    if (changes.paintings$)
    {
      changes.paintings$.currentValue.subscribe(paintings => 
        { 
          paintings.forEach((painting: Painting) =>
          {
            if (localStorage.getItem(painting.objectNumber) == "true")
            {
              painting.isFavorite = true;
            }
            else 
            {
              painting.isFavorite = false;
            }
          })
        });
      
      this.choosenPainting = null;
    }
  }

  paintingClicked(painting: Painting)
  {
    this.choosenPainting = painting;
  }

  changedFavorite(favorite: boolean) 
  {
    this.choosenPainting.isFavorite = favorite;

    if (typeof(Storage) == "undefined") 
    {
      console.log("Sorry, je browser ondersteunt geen Web Storage...");
    }
    else
    {
      var favoriteString = favorite ? "true" : "false";
      localStorage.setItem(this.choosenPainting.objectNumber, favoriteString);
    }
  }
}
